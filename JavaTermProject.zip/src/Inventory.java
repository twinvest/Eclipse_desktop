import java.util.ArrayList;

public class Inventory {
	int money;
	int numofmonsterball;
	int numofpotion;
	ArrayList<Monsterball> list = new ArrayList<>();
	Inventory(){};
	Inventory(int money){this.money = money;}
	
}