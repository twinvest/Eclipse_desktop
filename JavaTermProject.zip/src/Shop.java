
public class Shop {
	Monsterball ball;
	int potion = Integer.MAX_VALUE;
	
	
}
