
public class Monsterball {
	Poketmon p;
	
}
